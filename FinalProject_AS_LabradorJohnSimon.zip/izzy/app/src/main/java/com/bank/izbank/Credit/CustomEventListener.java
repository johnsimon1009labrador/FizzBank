package com.bank.izbank.Credit;

import android.view.View;

public interface CustomEventListener {

    public void MyEventListener();

}


