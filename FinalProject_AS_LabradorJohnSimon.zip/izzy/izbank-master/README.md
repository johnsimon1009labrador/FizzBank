# izbank

Hi 
I , Mete and Halil worked together to develop a mobile bank application
While doing this application, tasks were shared with each team member.
In order to be completely independent in this project, I learned the use of Git and Github with my teammates.
In addition, we supported each other when necessary and repaired the problems.
this added us time and efficiency while developing the app.

## This app features:
* Send money to another account
* Send money between own accounts
* Creating a bank account
* Creation of credit card
* Seeing the history of transactions
* Change of loan amount and rate according to profession group
* Loan payment
* Purchase of top 25 cryptocurrencies at Current values
* Storing the purchased crypto money (in this way, you can see the increase or decrease in value when you buy crypto money imaginary)
* Adding and paying the invoice
* Change user account settings
* Admin panel

## Used technologies:
* Parse database
* Retrofit
* Fragment
* OOP
* Java
* State Design Pattern

Youtube tutorial Link:https://youtu.be/P1VvbYsa2lQ
